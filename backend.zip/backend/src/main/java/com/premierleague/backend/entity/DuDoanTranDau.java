package com.premierleague.backend.entity;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "DuDoanTranDau")
public class DuDoanTranDau {
      @Id
    @Column(name = "MaDuDoan")
    private String maDuDoan;

    @Column(name = "MaTD")
    private String maTD;

    @Column(name = "XacSuatThangNha")
    private Double xacSuatThangNha;

    @Column(name = "XacSuatHoa")
    private Double xacSuatHoa;

    @Column(name = "XacSuatThangKhach")
    private Double xacSuatThangKhach;

    @Column(name = "NgayGioChayDuDoan")
    private LocalDateTime ngayGioChayDuDoan;

    @Column(name = "KetQuaThucTe")
    private String ketQuaThucTe;

    public String getMaDuDoan() { return maDuDoan; }
    public void setMaDuDoan(String maDuDoan) { this.maDuDoan = maDuDoan; }
    public String getMaTD() { return maTD; }
    public void setMaTD(String maTD) { this.maTD = maTD; }
    public Double getXacSuatThangNha() { return xacSuatThangNha; }
    public void setXacSuatThangNha(Double v) { this.xacSuatThangNha = v; }
    public Double getXacSuatHoa() { return xacSuatHoa; }
    public void setXacSuatHoa(Double v) { this.xacSuatHoa = v; }
    public Double getXacSuatThangKhach() { return xacSuatThangKhach; }
    public void setXacSuatThangKhach(Double v) { this.xacSuatThangKhach = v; }
    public LocalDateTime getNgayGioChayDuDoan() { return ngayGioChayDuDoan; }
    public void setNgayGioChayDuDoan(LocalDateTime v) { this.ngayGioChayDuDoan = v; }
    public String getKetQuaThucTe() { return ketQuaThucTe; }
    public void setKetQuaThucTe(String ketQuaThucTe) { this.ketQuaThucTe = ketQuaThucTe; }
}

package com.premierleague.backend.repository;

import com.premierleague.backend.entity.HopDong;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface HopDongRepository extends JpaRepository<HopDong, String> {
    List<HopDong> findByMaCT(String maCT);
    List<HopDong> findByMaCLB(String maCLB);
}
package com.premierleague.backend.repository;

import com.premierleague.backend.entity.CauLacBo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CauLacBoRepository extends JpaRepository<CauLacBo, String> {
}
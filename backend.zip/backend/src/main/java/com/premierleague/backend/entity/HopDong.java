package com.premierleague.backend.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "HopDong")
public class HopDong {
    @Id
    @Column(name = "MaHD")
    private String maHD;

    @Column(name = "MaCT")
    private String maCT;

    @Column(name = "MaCLB")
    private String maCLB;

    @Column(name = "ThoiGianKy")
    private LocalDate thoiGianKy;

    @Column(name = "ThoiGianKetThuc")
    private LocalDate thoiGianKetThuc;

    public String getMaHD() { return maHD; }
    public void setMaHD(String maHD) { this.maHD = maHD; }
    public String getMaCT() { return maCT; }
    public void setMaCT(String maCT) { this.maCT = maCT; }
    public String getMaCLB() { return maCLB; }
    public void setMaCLB(String maCLB) { this.maCLB = maCLB; }
    public LocalDate getThoiGianKy() { return thoiGianKy; }
    public void setThoiGianKy(LocalDate thoiGianKy) { this.thoiGianKy = thoiGianKy; }
    public LocalDate getThoiGianKetThuc() { return thoiGianKetThuc; }
    public void setThoiGianKetThuc(LocalDate thoiGianKetThuc) { this.thoiGianKetThuc = thoiGianKetThuc; }
}

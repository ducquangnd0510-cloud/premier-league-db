package com.premierleague.backend.entity;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "BoNhiemHLV")
public class BoNhiemHLV {
     @Id
    @Column(name = "MaBoNhiem")
    private String maBoNhiem;

    @Column(name = "MaHLV")
    private String maHLV;

    @Column(name = "MaCLB")
    private String maCLB;

    @Column(name = "NgayBoNhiem")
    private LocalDate ngayBoNhiem;

    @Column(name = "NgayKetThuc")
    private LocalDate ngayKetThuc;

    public String getMaBoNhiem() { return maBoNhiem; }
    public void setMaBoNhiem(String maBoNhiem) { this.maBoNhiem = maBoNhiem; }
    public String getMaHLV() { return maHLV; }
    public void setMaHLV(String maHLV) { this.maHLV = maHLV; }
    public String getMaCLB() { return maCLB; }
    public void setMaCLB(String maCLB) { this.maCLB = maCLB; }
    public LocalDate getNgayBoNhiem() { return ngayBoNhiem; }
    public void setNgayBoNhiem(LocalDate ngayBoNhiem) { this.ngayBoNhiem = ngayBoNhiem; }
    public LocalDate getNgayKetThuc() { return ngayKetThuc; }
    public void setNgayKetThuc(LocalDate ngayKetThuc) { this.ngayKetThuc = ngayKetThuc; }
}

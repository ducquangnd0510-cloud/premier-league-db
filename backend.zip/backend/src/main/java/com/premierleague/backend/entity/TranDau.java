package com.premierleague.backend.entity;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "TranDau")
public class TranDau {
    
    @Id
    @Column(name = "MaTD")
    private String maTD;

    @Column(name = "MaMuaGiai")
    private String maMuaGiai;

    @Column(name = "MaCLBNha")
    private String maCLBNha;

    @Column(name = "MaCLBKhach")
    private String maCLBKhach;

    @Column(name = "VongDau")
    private Integer vongDau;

    @Column(name = "ThoiGianThiDau")
    private LocalDateTime thoiGianThiDau;

    @Column(name = "SanVanDong")
    private String sanVanDong;

    @Column(name = "TiSoNha")
    private Integer tiSoNha;

    @Column(name = "TiSoKhach")
    private Integer tiSoKhach;

    public String getMaTD() { return maTD; }
    public void setMaTD(String maTD) { this.maTD = maTD; }
    public String getMaMuaGiai() { return maMuaGiai; }
    public void setMaMuaGiai(String maMuaGiai) { this.maMuaGiai = maMuaGiai; }
    public String getMaCLBNha() { return maCLBNha; }
    public void setMaCLBNha(String maCLBNha) { this.maCLBNha = maCLBNha; }
    public String getMaCLBKhach() { return maCLBKhach; }
    public void setMaCLBKhach(String maCLBKhach) { this.maCLBKhach = maCLBKhach; }
    public Integer getVongDau() { return vongDau; }
    public void setVongDau(Integer vongDau) { this.vongDau = vongDau; }
    public LocalDateTime getThoiGianThiDau() { return thoiGianThiDau; }
    public void setThoiGianThiDau(LocalDateTime thoiGianThiDau) { this.thoiGianThiDau = thoiGianThiDau; }
    public String getSanVanDong() { return sanVanDong; }
    public void setSanVanDong(String sanVanDong) { this.sanVanDong = sanVanDong; }
    public Integer getTiSoNha() { return tiSoNha; }
    public void setTiSoNha(Integer tiSoNha) { this.tiSoNha = tiSoNha; }
    public Integer getTiSoKhach() { return tiSoKhach; }
    public void setTiSoKhach(Integer tiSoKhach) { this.tiSoKhach = tiSoKhach; }
}

package com.premierleague.backend.repository;

import com.premierleague.backend.entity.CauThu;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CauThuRepository extends JpaRepository<CauThu, String> {
    List<CauThu> findByQuocTich(String quocTich);
    List<CauThu> findByViTri(String viTri);
    List<CauThu> findByHoTenContaining(String ten);
}
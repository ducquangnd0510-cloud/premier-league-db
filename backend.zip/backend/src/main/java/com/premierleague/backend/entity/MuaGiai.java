package com.premierleague.backend.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "MuaGiai")
public class MuaGiai {
     @Id
    @Column(name = "MaMuaGiai")
    private String maMuaGiai;

    @Column(name = "TenMuaGiai")
    private String tenMuaGiai;

    @Column(name = "ThoiGianBatDau")
    private LocalDate thoiGianBatDau;

    @Column(name = "ThoiGianKetThuc")
    private LocalDate thoiGianKetThuc;

    public String getMaMuaGiai() { return maMuaGiai; }
    public void setMaMuaGiai(String maMuaGiai) { this.maMuaGiai = maMuaGiai; }
    public String getTenMuaGiai() { return tenMuaGiai; }
    public void setTenMuaGiai(String tenMuaGiai) { this.tenMuaGiai = tenMuaGiai; }
    public LocalDate getThoiGianBatDau() { return thoiGianBatDau; }
    public void setThoiGianBatDau(LocalDate thoiGianBatDau) { this.thoiGianBatDau = thoiGianBatDau; }
    public LocalDate getThoiGianKetThuc() { return thoiGianKetThuc; }
    public void setThoiGianKetThuc(LocalDate thoiGianKetThuc) { this.thoiGianKetThuc = thoiGianKetThuc; }
}

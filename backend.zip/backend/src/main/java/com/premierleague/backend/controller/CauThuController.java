package com.premierleague.backend.controller;
import com.premierleague.backend.entity.CauThu;
import com.premierleague.backend.repository.CauThuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CauThuController {
     @Autowired
    CauThuRepository cauThuRepo;

    // Lấy tất cả cầu thủ
    @GetMapping("/cauthu")
    public List<CauThu> getAll() {
        return cauThuRepo.findAll();
    }

    // Lấy 1 cầu thủ theo mã
    @GetMapping("/cauthu/{ma}")
    public CauThu getOne(@PathVariable String ma) {
        return cauThuRepo.findById(ma).orElse(null);
    }

    // Tìm theo tên
    @GetMapping("/cauthu/tim")
    public List<CauThu> timTheoTen(@RequestParam String ten) {
        return cauThuRepo.findByHoTenContaining(ten);
    }

    // Tìm theo quốc tịch
    @GetMapping("/cauthu/quoctich/{quocTich}")
    public List<CauThu> timTheoQuocTich(@PathVariable String quocTich) {
        return cauThuRepo.findByQuocTich(quocTich);
    }

    // Thêm cầu thủ
    @PostMapping("/cauthu")
    public CauThu them(@RequestBody CauThu cauThu) {
        return cauThuRepo.save(cauThu);
    }

    // Xóa cầu thủ
    @DeleteMapping("/cauthu/{ma}")
    public void xoa(@PathVariable String ma) {
        cauThuRepo.deleteById(ma);
    }
}

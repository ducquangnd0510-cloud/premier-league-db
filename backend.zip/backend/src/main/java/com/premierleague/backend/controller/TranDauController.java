package com.premierleague.backend.controller;
import com.premierleague.backend.entity.TranDau;
import com.premierleague.backend.repository.TranDauRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class TranDauController {
    @Autowired
    TranDauRepository tranDauRepo;

    @GetMapping("/trandau")
    public List<TranDau> getAll() {
        return tranDauRepo.findAll();
    }

    @GetMapping("/trandau/{ma}")
    public TranDau getOne(@PathVariable String ma) {
        return tranDauRepo.findById(ma).orElse(null);
    }

    @GetMapping("/trandau/muagiai/{maMuaGiai}")
    public List<TranDau> theoMuaGiai(@PathVariable String maMuaGiai) {
        return tranDauRepo.findByMaMuaGiai(maMuaGiai);
    }

    @GetMapping("/bangxephang/{maMuaGiai}")
    public List<Object[]> bangXepHang(@PathVariable String maMuaGiai) {
        return tranDauRepo.bangXepHang(maMuaGiai);
    }

    @PostMapping("/trandau")
    public TranDau them(@RequestBody TranDau tranDau) {
        return tranDauRepo.save(tranDau);
    }
}

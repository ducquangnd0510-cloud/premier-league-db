package com.premierleague.backend.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "ThePhat")
public class ThePhat {
    @Id
    @Column(name = "MaTP")
    private String maTP;

    @Column(name = "MaTD")
    private String maTD;

    @Column(name = "MaHD")
    private String maHD;

    @Column(name = "PhutNhanThe")
    private Integer phutNhanThe;

    @Column(name = "LoaiThe")
    private String loaiThe;

    public String getMaTP() { return maTP; }
    public void setMaTP(String maTP) { this.maTP = maTP; }
    public String getMaTD() { return maTD; }
    public void setMaTD(String maTD) { this.maTD = maTD; }
    public String getMaHD() { return maHD; }
    public void setMaHD(String maHD) { this.maHD = maHD; }
    public Integer getPhutNhanThe() { return phutNhanThe; }
    public void setPhutNhanThe(Integer phutNhanThe) { this.phutNhanThe = phutNhanThe; }
    public String getLoaiThe() { return loaiThe; }
    public void setLoaiThe(String loaiThe) { this.loaiThe = loaiThe; }
}

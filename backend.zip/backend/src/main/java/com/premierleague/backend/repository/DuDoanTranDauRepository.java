package com.premierleague.backend.repository;

import com.premierleague.backend.entity.DuDoanTranDau;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface DuDoanTranDauRepository extends JpaRepository<DuDoanTranDau, String> {
    List<DuDoanTranDau> findByMaTDOrderByNgayGioChayDuDoanDesc(String maTD);
}
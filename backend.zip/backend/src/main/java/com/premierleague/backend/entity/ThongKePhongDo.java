package com.premierleague.backend.entity;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ThongKePhongDo")
public class ThongKePhongDo {
    @Id
    @Column(name = "MaThongKe")
    private String maThongKe;

    @Column(name = "MaCLB")
    private String maCLB;

    @Column(name = "MaTD")
    private String maTD;

    @Column(name = "SoTranThang5TranGanNhat")
    private Integer soTranThang5TranGanNhat;

    @Column(name = "TrungBinhBanThang")
    private Double trungBinhBanThang;

    @Column(name = "TrungBinhBanThua")
    private Double trungBinhBanThua;

    @Column(name = "SoNgayNghi")
    private Integer soNgayNghi;

    @Column(name = "ThoiDiemTinh")
    private LocalDateTime thoiDiemTinh;

    public String getMaThongKe() { return maThongKe; }
    public void setMaThongKe(String maThongKe) { this.maThongKe = maThongKe; }
    public String getMaCLB() { return maCLB; }
    public void setMaCLB(String maCLB) { this.maCLB = maCLB; }
    public String getMaTD() { return maTD; }
    public void setMaTD(String maTD) { this.maTD = maTD; }
    public Integer getSoTranThang5TranGanNhat() { return soTranThang5TranGanNhat; }
    public void setSoTranThang5TranGanNhat(Integer v) { this.soTranThang5TranGanNhat = v; }
    public Double getTrungBinhBanThang() { return trungBinhBanThang; }
    public void setTrungBinhBanThang(Double v) { this.trungBinhBanThang = v; }
    public Double getTrungBinhBanThua() { return trungBinhBanThua; }
    public void setTrungBinhBanThua(Double v) { this.trungBinhBanThua = v; }
    public Integer getSoNgayNghi() { return soNgayNghi; }
    public void setSoNgayNghi(Integer soNgayNghi) { this.soNgayNghi = soNgayNghi; }
    public LocalDateTime getThoiDiemTinh() { return thoiDiemTinh; }
    public void setThoiDiemTinh(LocalDateTime thoiDiemTinh) { this.thoiDiemTinh = thoiDiemTinh; }
}

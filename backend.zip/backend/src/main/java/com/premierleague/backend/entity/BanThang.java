package com.premierleague.backend.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "BanThang")
public class BanThang {
       @Id
    @Column(name = "MaBT")
    private String maBT;

    @Column(name = "MaTD")
    private String maTD;

    @Column(name = "MaHD")
    private String maHD;

    @Column(name = "PhutGhiBan")
    private Integer phutGhiBan;

    @Column(name = "LoaiBanThang")
    private String loaiBanThang;

    @Column(name = "MaHDKienTao")
    private String maHDKienTao;

    public String getMaBT() { return maBT; }
    public void setMaBT(String maBT) { this.maBT = maBT; }
    public String getMaTD() { return maTD; }
    public void setMaTD(String maTD) { this.maTD = maTD; }
    public String getMaHD() { return maHD; }
    public void setMaHD(String maHD) { this.maHD = maHD; }
    public Integer getPhutGhiBan() { return phutGhiBan; }
    public void setPhutGhiBan(Integer phutGhiBan) { this.phutGhiBan = phutGhiBan; }
    public String getLoaiBanThang() { return loaiBanThang; }
    public void setLoaiBanThang(String loaiBanThang) { this.loaiBanThang = loaiBanThang; }
    public String getMaHDKienTao() { return maHDKienTao; }
    public void setMaHDKienTao(String maHDKienTao) { this.maHDKienTao = maHDKienTao; }
}

package com.premierleague.backend.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "HuanLuyenVien")
public class HuanLuyenVien {
     @Id
    @Column(name = "MaHLV")
    private String maHLV;

    @Column(name = "HoTen")
    private String hoTen;

    @Column(name = "QuocTich")
    private String quocTich;

    public String getMaHLV() { return maHLV; }
    public void setMaHLV(String maHLV) { this.maHLV = maHLV; }
    public String getHoTen() { return hoTen; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }
    public String getQuocTich() { return quocTich; }
    public void setQuocTich(String quocTich) { this.quocTich = quocTich; }
}

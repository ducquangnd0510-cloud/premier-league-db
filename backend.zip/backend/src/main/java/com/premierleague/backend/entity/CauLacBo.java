package com.premierleague.backend.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "CauLacBo")
public class CauLacBo {
     @Id
    @Column(name = "MaCLB")
    private String maCLB;

    @Column(name = "TenCLB")
    private String tenCLB;

    @Column(name = "SanNha")
    private String sanNha;

    @Column(name = "ThanhPho")
    private String thanhPho;

    @Column(name = "NamThanhLap")
    private Integer namThanhLap;

    public String getMaCLB() { return maCLB; }
    public void setMaCLB(String maCLB) { this.maCLB = maCLB; }
    public String getTenCLB() { return tenCLB; }
    public void setTenCLB(String tenCLB) { this.tenCLB = tenCLB; }
    public String getSanNha() { return sanNha; }
    public void setSanNha(String sanNha) { this.sanNha = sanNha; }
    public String getThanhPho() { return thanhPho; }
    public void setThanhPho(String thanhPho) { this.thanhPho = thanhPho; }
    public Integer getNamThanhLap() { return namThanhLap; }
    public void setNamThanhLap(Integer namThanhLap) { this.namThanhLap = namThanhLap; }
}

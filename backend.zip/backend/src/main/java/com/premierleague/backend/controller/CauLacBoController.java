package com.premierleague.backend.controller;
import com.premierleague.backend.entity.CauLacBo;
import com.premierleague.backend.repository.CauLacBoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class CauLacBoController {
    @Autowired
    CauLacBoRepository cauLacBoRepo;

    @GetMapping("/clb")
    public List<CauLacBo> getAll() {
        return cauLacBoRepo.findAll();
    }

    @GetMapping("/clb/{ma}")
    public CauLacBo getOne(@PathVariable String ma) {
        return cauLacBoRepo.findById(ma).orElse(null);
    }

    @PostMapping("/clb")
    public CauLacBo them(@RequestBody CauLacBo clb) {
        return cauLacBoRepo.save(clb);
    }

    @DeleteMapping("/clb/{ma}")
    public void xoa(@PathVariable String ma) {
        cauLacBoRepo.deleteById(ma);
    }
}

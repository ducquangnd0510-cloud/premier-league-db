package com.premierleague.backend.repository;

import com.premierleague.backend.entity.TranDau;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface TranDauRepository extends JpaRepository<TranDau, String> {

    List<TranDau> findByMaMuaGiai(String maMuaGiai);

    @Query(value = """
        WITH KetQua AS (
            SELECT MaCLBNha AS MaCLB, TiSoNha AS BanThang, TiSoKhach AS BanThua
            FROM TranDau WHERE MaMuaGiai = :maMuaGiai AND TiSoNha IS NOT NULL
            UNION ALL
            SELECT MaCLBKhach, TiSoKhach, TiSoNha
            FROM TranDau WHERE MaMuaGiai = :maMuaGiai AND TiSoNha IS NOT NULL
        )
        SELECT clb.TenCLB,
            SUM(BanThang > BanThua)*3 + SUM(BanThang = BanThua) AS Diem,
            SUM(BanThang - BanThua) AS HieuSo,
            SUM(BanThang) AS TongBanThang
        FROM KetQua k JOIN CauLacBo clb ON k.MaCLB = clb.MaCLB
        GROUP BY clb.MaCLB, clb.TenCLB
        ORDER BY Diem DESC, HieuSo DESC, TongBanThang DESC
    """, nativeQuery = true)
    List<Object[]> bangXepHang(@Param("maMuaGiai") String maMuaGiai);
}
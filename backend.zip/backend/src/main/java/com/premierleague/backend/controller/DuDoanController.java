package com.premierleague.backend.controller;
import com.premierleague.backend.entity.DuDoanTranDau;
import com.premierleague.backend.repository.DuDoanTranDauRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class DuDoanController {
    @Autowired
    DuDoanTranDauRepository duDoanRepo;

    @GetMapping("/dudoan/{maTD}")
    public List<DuDoanTranDau> getDuDoan(@PathVariable String maTD) {
        return duDoanRepo.findByMaTDOrderByNgayGioChayDuDoanDesc(maTD);
    }

    @PostMapping("/dudoan")
    public DuDoanTranDau them(@RequestBody DuDoanTranDau duDoan) {
        return duDoanRepo.save(duDoan);
    }
}
